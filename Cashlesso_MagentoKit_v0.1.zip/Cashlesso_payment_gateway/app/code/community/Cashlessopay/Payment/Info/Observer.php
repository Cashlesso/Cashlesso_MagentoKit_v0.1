<?php

class Cashlessopay_Payment_Info_Observer {

    public function check_status(Varien_Event_Observer $observer) {
        $session = Mage::getSingleton('cashlessopay/session');
        $payment = $observer->getPayment();
        $payment_method = $observer->getPayment()->getMethodInstance();
        $orderId = $payment->getOrder()->getIncrementId();
		$customerData = Mage::getModel('customer/customer')->load($customer_id);
        $customerName = $customerData->getName();
        if ($payment_method->getCode() == 'cashlessopay') {
            // check in session cache
          //  $status = $session->getTransactStatus($orderId);            
            //if ($status == null) {
                // get the status here
                $status = $payment_method->checkStatus($payment);
              //  $session->setTransactStatus($orderId, $status);
            //}
            $observer->getTransport()->setData('Latest Cashlessopay Status', $status);            
        }
        return $this;
    }

}