<?php

class Cashlessopay_Model_Transact extends Mage_Payment_Model_Method_Abstract 
{

    protected $_code = 'cashlessopay';

    /* protected $_canAuthorize            = true; */
    protected $_canCapture              = true;
    protected $_isInitializeNeeded      = true;
    protected $_canUseInternal          = false;
    protected $_canUseForMultishipping  = false;
    protected $_canVoid                 = true;
    protected $_canRefund               = true;

    /**
     * Return Order place redirect url
     *
     * @return string
     */
    public function getOrderPlaceRedirectUrl()
    {
       return Mage::getUrl('cashlessopay/transact/redirect', array('_secure' => true));
    }
    /**
     * A wrapper method to access the checkout and order details
     * stored in the session
     * @param ? Session
     */
    public function getCheckout() 
    {
        return Mage::getSingleton('checkout/session');
    }

    /**
     * Instantiate state and set it to state object
     * @param string $paymentAction
     * @param Varien_Object
     */
    public function initialize($paymentAction, $stateObject)
    {
        $state = Mage_Sales_Model_Order::STATE_PENDING_PAYMENT;
        $stateObject->setState($state);
        $stateObject->setStatus('pending_payment');
        $stateObject->setIsNotified(false);
    }

    /**
     * Method to get the form fields with the relevant fields filled in
     * @return Array of form fields in the name=>value form 
     */
    public function getCheckoutFormFields() 
    {
        $orderIncrementId = $this->getCheckout()->getLastRealOrderId();

        $order = Mage::getModel('sales/order')->loadByIncrementId($orderIncrementId);
        $this->getCheckout()->setCashlessopayOrderId($orderIncrementId);
        $api = Mage::getModel('cashlessopay/api_transact')->setConfigObject($this->getConfig());
        $api->setOrderId($orderIncrementId)
            ->setCurrencyCode($order->getBaseCurrencyCode())
            ->setOrder($order)
            ->setCashlessopayConfig(Mage::getStoreConfig('payment/cashlessopay'))
            ->setReturnUrl(Mage::getUrl('cashlessopay/transact/response'));
        // export address
        $isOrderVirtual = $order->getIsVirtual();
        $api->setBillingAddress($order->getBillingAddress());
        if ($isOrderVirtual) {
            $api->setNoShipping(true);
        } elseif ($order->getShippingAddress()->validate()) {
            $api->setShippingAddress($order->getShippingAddress());
        }
        // add cart totals and line items
        $result = $api->getRequestFields();
        $this->getCheckout()->setCashlessopayChecksum($api->getCashlessopayChecksum());
        return $result;
    }  

    	public function CaptureCashlessopaySuccessOrderState(){
		$config = Mage::getStoreConfig('payment/cashlessopay');
        $order_status = $config['order_status'];
        switch ($order_status) {
        
        case "pending":
        default:
            $state = Mage_Sales_Model_Order::STATE_PROCESSING;
        }
        return $state;
	}

    public function capture(Varien_Object $payment, $amount) 
    {
        $order = $payment->getOrder();
        $api = Mage::getModel('cashlessopay/api_update');
        $api->send($order->getIncrementId(), Cashlessopay_Model_Api_Update::$STATUS_SETTLED, 'payment captured');        
        if ($api->getResponseCode() == 196) {
            Mage::throwException('Online Capture failed. Cashlessopay Update Api responded Response Code: '.$api->getResponseCode() . ' Message: ' . $api->getResponseDescription());
            Mage::log('Cashlessopay update api failure: orderId: '.$order->getIncrementId() . ', responseCode: ' . $api->getResponseCode(). ', responseDescription: ' . $api->getResponseDescription());
        }
    }

    public function cancel(Varien_Object $payment) 
    {
        $order = $payment->getOrder();
        $api = Mage::getModel('cashlessopay/api_update');
        $api->send($order->getIncrementId(), Cashlessopay_Model_Api_Update::$STATUS_CANCELLED, 'order cancelled');
		//*****************************************************//
		$order_check = $payment->getOrder();
        $api_check = Mage::getModel('cashlessopay/api_check');
        $api_check->check($order_check->getIncrementId());
		$response_code = $api_check->getResponseCode();
		if(!$response_code == 213 )	// transaction already cancelled by merchant
		{
		   if( !in_array($api->getResponseCode(), array(243,230)))
		{
            Mage::throwException('Request could not be completed since Cashlessopay Update Api responded with update failure. Response Code: '.$api->getResponseCode());
            Mage::log('Cashlessopay update api failure: orderId: '.$order->getIncrementId() . ', responseCode: ' . $api->getResponseCode(). ', responseDescription: ' . $api->getResponseDescription());
        }}
    }

    public function void(Varien_Object $payment) {
        $order = $payment->getOrder();
        $api = Mage::getModel('cashlessopay/api_update');
        $api->send($order->getIncrementId(), Cashlessopay_Model_Api_Update::$STATUS_CANCELLED, 'order void');        
        if (!in_array($api->getResponseCode(), array(226, 198, 213,243))) {
            Mage::throwException('Request could not be completed since Cashlessopay Update Api responded with update failure. Response Code: '.$api->getResponseCode());
            Mage::log('Cashlessopay update api failure: orderId: '.$order->getIncrementId() . ', responseCode: ' . $api->getResponseCode(). ', responseDescription: ' . $api->getResponseDescription());
        }
    }

    // refund cannot be consumed as there is no api to capture funds
    public function refund(Varien_Object $payment, $amount) 
    {
        Mage::log('refund is getting called');
    }

    // call the check transaction api to show the current status
    public function checkStatus(Varien_Object $payment) 
    {
        $order = $payment->getOrder();
        $api = Mage::getModel('cashlessopay/api_check');
        $api->check($order->getIncrementId());
        $status = $api->getResponseDescription();
        return $status;
    }
}
