<?php 

class Cashlessopay_Model_Api_Check extends Varien_Object 
{

    public static $CHECK_ENDPOINT = 'https://api.caslessopay.com/checktransaction';
    
    public function check($orderId)
    {
        $request = Mage::getModel('cashlessopay/api_request');
        $request->setCashlessopayConfig(Mage::getStoreConfig('payment/cashlessopay'))
            ->setUrl(self::$CHECK_ENDPOINT)
            ->addParam('orderId', $orderId)
            ->send();
        $this->setResponseCode($request->getResponseCode());
        $this->setResponseDescription($request->getResponseDescription());
    }
}
