<?php

require_once Mage::getBaseDir('lib') . '/Cashlessopay/checksum.php';

/**
 * Cashlesso Payment Gateway Transaction API
 */
class Cashlessopay_Model_Api_Transact extends Varien_Object
{

    protected $_checksum = null;

    protected $_globalMap = array(
        // commands
        'PAY_ID' => '',
        'ORDER_ID' => '',
        'RETURN_URL' => '',
        'CUST_EMAIL' => '',
        'CUST_NAME' => '',
        'CUST_STREET_ADDRESS1' => '',
        'CUST_CITY' => '',
        'CUST_STATE' => '',
        'CUST_COUNTRY' => '',
        'CUST_ZIP' => '',
        'CUST_PHONE' => '',
        'TXNTYPE' => 'SALE',
        'CURRENCY_CODE' => '356',
        'AMOUNT' => '',
        'PRODUCT_DESC' => '',
        'CUST_SHIP_STREET_ADDRESS1' => '',
        'CUST_SHIP_CITY' => '',
        'CUST_SHIP_STATE' => '',
        'CUST_SHIP_COUNTRY' => '',
        'CUST_SHIP_ZIP' => '',
        'CUST_SHIP_PHONE' => '',
        'CUST_SHIP_NAME' => '',
    );

    protected $_mandatory = array(
        'PAY_ID',
        'ORDER_ID',
        'CURRENCY_CODE',
        'AMOUNT',
        'TXNTYPE',
        'RETURN_URL',
        'HASH',
    );

    private function _validateFields($fields) 
    {
        // mode is an exceptional case here as it may take a value '0' or 0 here so we handle that first
        if (!in_array($fields['mode'], array(0, 1))) {
            throw new Exception('Cashlessopay requires that the field mode can take only values 0 and 1');
        }
        unset($fields['mode']);
        foreach ($fields as $key=>$value) {
            if (in_array($key, $this->_mandatory) && !$value) {
                throw new Exception('Cashlessopay requires the field ' . $key . ' to be mandatory.');
            }
        }        
    }

    private function _buildRequestFields() 
    {
        $fields = $this->_globalMap;
        $cashlessopayConfig = $this->getCashlessopayConfig();
		if($cashlessopayConfig['request_url']=="1"){
			$reqUrl = "https://uat.cashlesso.com/pgui/jsp/paymentrequest";
		}else{
			$reqUrl = "https://www.cashlesso.com/pgui/jsp/paymentrequest";
		}
        $order = $this->getOrder();
        $order_data = $order->getData();
        $billingAddress = $this->getBillingAddress();
        $shippingAddress = $this->getShippingAddress();
        $amount = $this->_convertAmount($order->getGrandTotal(), $order->getOrderCurrencyCode());
        $currency = 356;
      
        $fields = array_merge($this->_globalMap, array(
            'ACTION' => $reqUrl,
            'PAY_ID' => $cashlessopayConfig['merchant_id'],
            'ORDER_ID' => $order->getIncrementId(),
            'RETURN_URL' => $this->getReturnUrl(),
            'CUST_EMAIL' => $order->getCustomerEmail(),
            'CUST_NAME' => $order->getCustomerFirstname(),
            'CUST_STREET_ADDRESS1' => $this->_joinAddressStreet($billingAddress->getStreet()),
            'CUST_CITY' => $billingAddress->getCity(),
            'CUST_STATE' => $billingAddress->getRegion(),
            'CUST_COUNTRY' => $this->_getCountryNameByCode($billingAddress->getCountry()),
            'CUST_ZIP' => $billingAddress->getPostcode(),
            'CUST_PHONE' => $billingAddress->getTelephone(),
            'CURRENCY_CODE' => $currency,
            'AMOUNT' => $amount,
            'PRODUCT_DESC' => 'Order Id ' . $order->getIncrementId(),
        ));
        // set the shipping address too if the order is not virtual
        if (!$order->getIsVirtual()) {
            $fields = array_merge($fields, array(
                'CUST_SHIP_STREET_ADDRESS1' => $this->_joinAddressStreet($shippingAddress->getStreet()),
                'CUST_SHIP_CITY' => $shippingAddress->getCity(),
                'CUST_SHIP_STATE' => $shippingAddress->getRegion(),
                'CUST_SHIP_COUNTRY' => $this->_getCountryNameByCode($shippingAddress->getCountry()),
                'CUST_SHIP_ZIP' => $shippingAddress->getPostcode(),
                'CUST_SHIP_PHONE' => $shippingAddress->getTelephone(),
                'CUST_SHIP_NAME' => $order->getCustomerFirstname(),
            ));
        }
        return $fields;
    }

    /**
     * Method to return the country name by the country code
     */
    private function _getCountryNameByCode($code) 
    {
        $countryModel = Mage::getModel('directory/country')->loadByCode($code);
        return ucfirst($countryModel->getName());        
    }

    /**
     * Method to convert the amount to INR
     * @param decimal $amount
     * @param String $currency
     */
    private function _convertAmount($amount, $currencyCode) 
    {   
	    $backamount = 0 ;
        if ($currencyCode == 'INR' ) {
            $backamount = floor($amount * 100);           
        }
		if (($currencyCode != 'INR') && ($currencyCode != 'USD')) {
            $amount = Mage::helper('directory')->currencyConvert($amount, $currencyCode, 'INR');
			$backamount = floor($amount * 100);            
        }
		if ($currencyCode == 'USD') {
            $backamount = floor($amount * 100);
        }
		return $backamount;
    }
      
    /**
     * Method to join Street 1 and Street 2 in an address to a single string
     * @param mixed $address (String|Array)
     * @return String $address
     */
    private function _joinAddressStreet($address) 
    {
        if (is_array($address)) {            
            $address = array_map('trim', $address);
            $joined = implode(" ", $address);
            return substr($joined, 0, 30);
        }
        return $address;
    }

    /**
     * Method to concatenate the fields into a string
     * using which the checksum will be creaeted
     * @param Array $fields
     * @param String
     */
    public function _concatFields($fields) 
    {
        unset($fields['checksum']);
       return "'" . implode("'", $fields) . "'";
    }

    public function getRequestFields() 
    {
        $fields = $this->_buildRequestFields();
        // pass it through validate so that an exception is thrown
        $this->_validateFields($fields);
     error_log("Logging stripped params : " . $fields);
        $cashlessopayConfig = $this->getCashlessopayConfig();
        $checksum = Checksum::calculateChecksum($cashlessopayConfig['secret_key'], $fields);
		error_log("Logging stripped params : " . $fields);
	error_log('Logging key used to produce checksum : ' . $cashlessopayConfig['secret_key']);
	error_log('Logging checksum : ' . $checksum);
        $this->_checksum = $checksum;
        
        // first sort by key and then append checksum in the end 
        $fields['HASH'] = $checksum;
        return $fields;
    }

    public function getCashlessopayChecksum() 
    {
        return $this->_checksum;
    }
}

