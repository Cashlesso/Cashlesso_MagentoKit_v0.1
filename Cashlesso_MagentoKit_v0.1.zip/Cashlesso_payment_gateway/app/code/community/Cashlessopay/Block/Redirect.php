<?php 

class Cashlessopay_Block_Redirect extends Mage_Core_Block_Abstract 
{
    protected function _toHtml() 
    {
        $cashlessopay = Mage::getModel('cashlessopay/transact');
        $fields = $cashlessopay->getCheckoutFormFields();
        $requesturl="";
        $hiddenfields="";
        foreach($fields as $key => $value) {
            if ($key == 'ACTION') {
                        $requesturl = $value;
            } else {
			$hiddenfields .= '<input type="hidden" name="'.$key.'" value="'.$value.'" />'."\n";
            }
        }
        // Preparing request for payment.
        $form = '<form id="cashlessopay_checkout" method="POST" action="' . $requesturl . '">';
        $form .= $hiddenfields;
        $form .= '</form>';
        $html = '<html><body>';
        $html .= $this->__('You will be redirected to the Cashlesso website in a few seconds. Thanks for using Cashlesso');
        $html .= $form;
        $html.= '<script type="text/javascript">document.getElementById("cashlessopay_checkout").submit();</script>';
        $html.= '</body></html>';
        return $html;
    }
}