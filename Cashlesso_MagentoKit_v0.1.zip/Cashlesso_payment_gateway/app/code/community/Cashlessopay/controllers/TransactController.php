<?php 

require_once Mage::getBaseDir('lib') . '/Cashlessopay/checksum.php';

class Cashlessopay_TransactController extends Mage_Core_Controller_Front_Action 
{
    /**
     * Set the quote Id generated in the table into session
     * and add the block of cashlesso form which will submit itself
     * to the cashlesso site
     */
    public function redirectAction() 
    {
        $session = Mage::getSingleton('checkout/session');
        $session->setCashlessopayQuoteId($session->getQuoteId());
        $this->getResponse()->setBody($this->getLayout()->createBlock('cashlessopay/redirect')->toHtml());
        $session->unsQuoteId();
        $session->unsRedirectUrl();
    }

    public function responseAction() 
    {
        // actual processing
        $postdata = Mage::app()->getRequest()->getPost();
        $session = Mage::getSingleton('checkout/session');
        $session->setQuoteId($session->getCashlessopayQuoteId(true));
	$cashlessopayConfig = Mage::getStoreConfig('payment/cashlessopay');
        ksort($postdata);
        $all="";
	// 	Checksum Verification
	//	Proceed only if checksum matches. Else redirect to error page.
	    foreach( $postdata as $name => $value){
                    $all .= $name;
		    $all .= "=";
		    $all.= $value;
		    $all .= "~";
            }
	 error_log("Logging response params :" . $all);
         $checksumReceived = $postdata['HASH'];
         unset($postdata['HASH']);

	$checksumCalculated = Checksum::calculateChecksum($cashlessopayConfig['secret_key'], $postdata);
        
	error_log('Logging checksum : ' . $checksumCalculated);
	if ($checksumReceived != $checksumCalculated) {
		if ($session->getLastRealOrderId()) {
                	$order = Mage::getModel('sales/order')->loadByIncrementId($session->getLastRealOrderId());
                	if ($order->getId()) {
                    		$order->cancel()->save();
                	}
            	}
		$er = 'Checksum does not match. This response has been compromised. However, transaction might have been successful.';
            	$session->addError($er);
            	$this->_redirect('cashlessopay/transact/failure');
		return;
	}


        // success
        if ($this->_validateResponse()) {
            Mage::getSingleton('checkout/session')->getQuote()->setIsActive(false)->save();
            // load the order and change the order status
            $cashlessopay = Mage::getModel('cashlessopay/transact');
			if($postdata['STATUS']=="Captured" || $postdata['STATUS']=="000"){
				$state = $cashlessopay->CaptureCashlessopaySuccessOrderState();
			}else{
            $state = "Failed";
			}
              
             $order = Mage::getModel('sales/order')->loadByIncrementId($postdata['ORDER_ID']);   
            $order->setData('state', $state);
            $order->setStatus($state);
			$order->addStatusHistoryComment('Your Order Status is: '.$postdata['STATUS'].' Your Order TXN_ID: '.$postdata['TXN_ID'].
			' Order Txn_Response_Message: '.$postdata['RESPONSE_MESSAGE'].' and Order Payment Type is: '.$postdata['PAYMENT_TYPE']);
			
            // also do something similar to capturing the payment here            
            $payment = $order->getPayment();
            $transaction = Mage::getModel('sales/order_payment_transaction');
            $dummy_txn_id = 'Cashlessopay_'.$postdata['ORDER_ID'];
            $transaction->setOrderPaymentObject($payment)
                ->setTxnId($dummy_txn_id)
                ->setTxnType(Mage_Sales_Model_Order_Payment_Transaction::TYPE_AUTH)
                ->setIsClosed(0)
                ->save();
            $order->save();
            try
			{
			$order->sendNewOrderEmail();
			} catch (Exception $ex) {  }            
			
            $this->_redirect('checkout/onepage/success', array('_secure'=>true));
        } else {
            // failure/cancel
            if ($session->getLastRealOrderId()) {
                $order = Mage::getModel('sales/order')->loadByIncrementId($session->getLastRealOrderId());
                if ($order->getId()) {
                    $order->cancel()->save();
                }
            }
            $er = 'Cashlessopay could not process your request because of the error "'.$postdata['responseDescription'] . '"'; 
            $session->addError($er);
            $this->_redirect('cashlessopay/transact/failure');
        }
    }

    /**
     * Verify the response coming into the server
     * @return boolean
     */
    protected function _validateResponse() 
    {
        $postdata = Mage::app()->getRequest()->getPost();
        $flag = False;  
        $code = $postdata['RESPONSE_CODE'];                
        error_log('Response Code is ' . $code);
	
        if($code==='000'){	
            $flag = True;
        }
        return $flag;
    }

    public function failureAction() 
    {
        $this->loadLayout();        
        $this->_initLayoutMessages('checkout/session');
        $this->renderLayout();
    }
}
