<?php 

class Cashlessopay_IndexController extends Mage_Core_Controller_Front_Action {

    public function indexAction() {
      
        $this->testSession();
    }

    protected function testTransact() {
        $order = Mage::getModel('sales/order')
            ->load(27);
        $config = Mage::getStoreConfig('payment/cashlessopay');
        var_dump($config); exit;

        $cashlessopay = Mage::getModel('cashlessopay/transact');
        $fields = $cashlessopay->getCheckoutFormFields();
        $form = '<form id="cashlessopay_checkout" method="POST" action="' . $cashlessopay->getcashlessoTransactAction() . '">';
        foreach($fields as $key => $value) {
            $form .= '<input type="hidden" name="'.$key.'" value="'.$value.'" />'."\n";
        }
        $form .= '</form>';
        $html = '<html><body>';
        $html .= $this->__('You will be redirected to the Cashlesso website in a few seconds.');
        $html .= $form;
        $html.= '</body></html>';
        echo $html;
        exit;
    }

    protected function testUpdate() {
        $request = Mage::getModel('cashlessopay/api_request');
        $request->setCashlessopayConfig(Mage::getStoreConfig('payment/cashlessopay'))
            ->setUrl('https://api.cashlesso.com/updatetransaction')
            ->addParam('orderId', '100000040')
            ->addParam('updateDesired', '7')
            ->addParam('updateReason', 'Lorem Ipsum')
            ->send();
    }

    protected function testPayment() {
        $order = Mage::getModel('sales/order')
            ->load(27);
        var_dump($order->getPayment()); exit;
    }

    protected function testSession() {
        $session = Mage::getSingleton('cashlessopay/session');
        var_dump($session->getTransactStatus('100000082')); exit;        
    }
}
